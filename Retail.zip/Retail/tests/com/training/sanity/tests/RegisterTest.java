package com.training.sanity.tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;

import com.training.generics.ScreenShot;
import com.training.pom.RegisterPOM;
import com.training.utility.DriverFactory;
import com.training.utility.DriverNames;

public class RegisterTest {

	private WebDriver driver;
	private String baseUrl;
	private RegisterPOM registerPOM;


	@BeforeClass
	public void setUp() throws Exception {
		driver = DriverFactory.getDriver(DriverNames.CHROME);
		registerPOM = new RegisterPOM(driver);
		baseUrl = "http://retailm1.upskills.in/account/register"; 
		driver.get(baseUrl);
	}

	@AfterMethod
	public void tearDown() throws Exception {
		Thread.sleep(5000);
		driver.quit();
	}

	@Test
	public void loginPassTest() {
		registerPOM.sendFName("reva");
		registerPOM.sendLName("sharma");
		registerPOM.sendEmailName("revasharma@gmail.com");
		registerPOM.sendTelephone("9345677833");
		registerPOM.sendAdd1("Jayanagar");
		registerPOM.sendAdd2("bangalore");
		registerPOM.sendCity("bangalore");
		registerPOM.sendPostcode("560018");
		registerPOM.sendCountry("India");
		registerPOM.sendState("Karnataka");
		registerPOM.sendConfirmPassword("reva123");
		registerPOM.sendPassword("reva123");
		registerPOM.clickCheckBox();
		registerPOM.clickContinueBtn();
			}

}
