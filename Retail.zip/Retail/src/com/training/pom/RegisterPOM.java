package com.training.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPOM {
private WebDriver driver; 
	
	public RegisterPOM(WebDriver driver) {
		this.driver = driver; 
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="input-firstname")
	private WebElement firstname; 	
	@FindBy(id="input-lastname")
	private WebElement lastname;
	@FindBy(id="input-email")
	private WebElement email;	
	@FindBy(id="input-telephone")
	private WebElement telephone;
	@FindBy(id="input-address-1")
	private WebElement add1; 	
	@FindBy(id="input-address-2")
	private WebElement add2;
	@FindBy(id="input-city")
	private WebElement city;	
	@FindBy(id="input-postcode")
	private WebElement postcode;
	@FindBy(id="input-country")
	private WebElement country; 	
	@FindBy(id="input-password")
	private WebElement password;
	@FindBy(id="input-zone")
	private WebElement zone;	
	@FindBy(id="input-confirm")
	private WebElement confirmValue;
	@FindBy(name="agree")
	private WebElement agreeBtn;
	//@FindBy(type="submit")
	private WebElement continueBtn= driver.findElement(By.xpath("//*[@id=\"System_nyHsmShk\"]/form/div/div[2]/input"));
	
	public void sendFName(String fName) {
		this.firstname.sendKeys(fName);
	}	
	public void sendLName(String lName) {
		this.lastname.sendKeys(lName); 
	}
	public void sendEmailName(String email) {
		this.email.sendKeys(email);
	}	
	public void sendTelephone(String tele) {
		this.telephone.sendKeys(tele); 
	}
	public void sendAdd1(String ad1) {
		this.add1.sendKeys(ad1);
	}	
	public void sendAdd2(String ad2) {
		this.add2.sendKeys(ad2); 
	}
	public void sendCity(String cityName) {
		this.city.sendKeys(cityName);
	}
	public void sendPostcode(String postc) {
		this.postcode.sendKeys(postc); 
	}
	public void sendCountry(String countryName) {
		this.country.sendKeys(countryName);
	}	
	public void sendState(String states) {
		this.zone.sendKeys(states); 
	}
	public void sendConfirmPassword(String confirmPassword) {
		this.confirmValue.sendKeys(confirmPassword);
	}	
	public void sendPassword(String password) {
		this.password.sendKeys(password); 
	}
	public void clickCheckBox() {
		this.agreeBtn.click(); // checkbox will be selected or clicked? what will be code part?not sure. so copied it as button
	}
	public void clickContinueBtn() {
		this.continueBtn.click(); 
	}

}
